﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ABU_BAKER_GUL_20194401
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const double mumtaz = 0.200;
        const double jayed = 0.140;
        const double speical = 0.180;
        const double super = 0.235;
        const int fixedtank = 50;

        private void AcessButton_Click(object sender, EventArgs e)
        {
            int car;
            try
            {
                car = int.Parse(CarnotextBox.Text);
                panel1.Enabled = true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Car can not be numeric","Invlaid data",MessageBoxButtons.OK ,MessageBoxIcon.Error);
            }
        }

        private void Addtobillbutton_Click(object sender, EventArgs e)
        {
            double amount=0;
            double priceofthefuel=0;
            double fixedamount;
            double liters;
         
            string s;
            s = TypecomboBox.SelectedItem.ToString();
           

            if (s == "Mumatz") 
            {
                priceofthefuel = mumtaz;
            }
            if(s=="Jayed")
            {
                priceofthefuel = jayed;
            }
            if (s=="Speical")
            {
                priceofthefuel = speical;
            }
            if (s=="Super")
            {
                priceofthefuel = super;
            }


            
                fixedamount = double.Parse(AmounttextBox.Text);

                liters = fixedamount / priceofthefuel;
                displayliters.Text = liters.ToString();

            if (Fulltankradiobutton.Checked)
            {
                amount = fixedtank * priceofthefuel;

            }
            BilllistBox.Items.Add("petrol" + TypecomboBox.SelectedItem + liters);
            Amountlist.Items.Add(amount);
        }

        private void Clearbutton_Click(object sender, EventArgs e)
        {
            BilllistBox.Items.Clear();
        }

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
