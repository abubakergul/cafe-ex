﻿
namespace ABU_BAKER_GUL_20194401
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.GearcheckBox = new System.Windows.Forms.CheckBox();
            this.EnginecheckBox = new System.Windows.Forms.CheckBox();
            this.OilChange = new System.Windows.Forms.ListBox();
            this.displayliters = new System.Windows.Forms.Label();
            this.Literslabel = new System.Windows.Forms.Label();
            this.AmounttextBox = new System.Windows.Forms.TextBox();
            this.Amountlabel = new System.Windows.Forms.Label();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.TypecomboBox = new System.Windows.Forms.ComboBox();
            this.Typelabel = new System.Windows.Forms.Label();
            this.Fulltankradiobutton = new System.Windows.Forms.RadioButton();
            this.FixedamountradioButton = new System.Windows.Forms.RadioButton();
            this.DieselradioButton = new System.Windows.Forms.RadioButton();
            this.PetrolradioButton = new System.Windows.Forms.RadioButton();
            this.Sales = new System.Windows.Forms.ListBox();
            this.Fuel = new System.Windows.Forms.ListBox();
            this.Addtobillbutton = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Carnolabel = new System.Windows.Forms.Label();
            this.CarnotextBox = new System.Windows.Forms.TextBox();
            this.AcessButton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BillButton = new System.Windows.Forms.Button();
            this.NextcustomerButton = new System.Windows.Forms.Button();
            this.AboutButton = new System.Windows.Forms.Button();
            this.Exitbutton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Amountlist = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BilllistBox = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.Addtobillbutton);
            this.panel1.Controls.Add(this.GearcheckBox);
            this.panel1.Controls.Add(this.EnginecheckBox);
            this.panel1.Controls.Add(this.OilChange);
            this.panel1.Controls.Add(this.displayliters);
            this.panel1.Controls.Add(this.Literslabel);
            this.panel1.Controls.Add(this.AmounttextBox);
            this.panel1.Controls.Add(this.Amountlabel);
            this.panel1.Controls.Add(this.Clearbutton);
            this.panel1.Controls.Add(this.TypecomboBox);
            this.panel1.Controls.Add(this.Typelabel);
            this.panel1.Controls.Add(this.Fulltankradiobutton);
            this.panel1.Controls.Add(this.FixedamountradioButton);
            this.panel1.Controls.Add(this.DieselradioButton);
            this.panel1.Controls.Add(this.PetrolradioButton);
            this.panel1.Controls.Add(this.Sales);
            this.panel1.Controls.Add(this.Fuel);
            this.panel1.Enabled = false;
            this.panel1.Location = new System.Drawing.Point(48, 38);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(740, 220);
            this.panel1.TabIndex = 5;
            // 
            // GearcheckBox
            // 
            this.GearcheckBox.AutoSize = true;
            this.GearcheckBox.Location = new System.Drawing.Point(196, 184);
            this.GearcheckBox.Name = "GearcheckBox";
            this.GearcheckBox.Size = new System.Drawing.Size(49, 17);
            this.GearcheckBox.TabIndex = 34;
            this.GearcheckBox.Text = "&Gear";
            this.GearcheckBox.UseVisualStyleBackColor = true;
            // 
            // EnginecheckBox
            // 
            this.EnginecheckBox.AutoSize = true;
            this.EnginecheckBox.Location = new System.Drawing.Point(196, 161);
            this.EnginecheckBox.Name = "EnginecheckBox";
            this.EnginecheckBox.Size = new System.Drawing.Size(59, 17);
            this.EnginecheckBox.TabIndex = 33;
            this.EnginecheckBox.Text = "E&ngine";
            this.EnginecheckBox.UseVisualStyleBackColor = true;
            // 
            // OilChange
            // 
            this.OilChange.FormattingEnabled = true;
            this.OilChange.Location = new System.Drawing.Point(176, 130);
            this.OilChange.Name = "OilChange";
            this.OilChange.Size = new System.Drawing.Size(170, 82);
            this.OilChange.TabIndex = 32;
            // 
            // displayliters
            // 
            this.displayliters.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayliters.Location = new System.Drawing.Point(631, 76);
            this.displayliters.Name = "displayliters";
            this.displayliters.Size = new System.Drawing.Size(100, 23);
            this.displayliters.TabIndex = 31;
            // 
            // Literslabel
            // 
            this.Literslabel.AutoSize = true;
            this.Literslabel.Location = new System.Drawing.Point(577, 86);
            this.Literslabel.Name = "Literslabel";
            this.Literslabel.Size = new System.Drawing.Size(32, 13);
            this.Literslabel.TabIndex = 30;
            this.Literslabel.Text = "Liters";
            // 
            // AmounttextBox
            // 
            this.AmounttextBox.Location = new System.Drawing.Point(631, 31);
            this.AmounttextBox.Name = "AmounttextBox";
            this.AmounttextBox.Size = new System.Drawing.Size(100, 20);
            this.AmounttextBox.TabIndex = 29;
            // 
            // Amountlabel
            // 
            this.Amountlabel.AutoSize = true;
            this.Amountlabel.Location = new System.Drawing.Point(574, 31);
            this.Amountlabel.Name = "Amountlabel";
            this.Amountlabel.Size = new System.Drawing.Size(43, 13);
            this.Amountlabel.TabIndex = 28;
            this.Amountlabel.Text = "Amount";
            // 
            // Clearbutton
            // 
            this.Clearbutton.Location = new System.Drawing.Point(196, 98);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(75, 23);
            this.Clearbutton.TabIndex = 27;
            this.Clearbutton.Text = "&Clear";
            this.Clearbutton.UseVisualStyleBackColor = true;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // TypecomboBox
            // 
            this.TypecomboBox.FormattingEnabled = true;
            this.TypecomboBox.Items.AddRange(new object[] {
            "Mumtaz",
            "Jayed",
            "Special",
            "Super"});
            this.TypecomboBox.Location = new System.Drawing.Point(176, 50);
            this.TypecomboBox.Name = "TypecomboBox";
            this.TypecomboBox.Size = new System.Drawing.Size(121, 21);
            this.TypecomboBox.TabIndex = 26;
            // 
            // Typelabel
            // 
            this.Typelabel.AutoSize = true;
            this.Typelabel.Location = new System.Drawing.Point(214, 19);
            this.Typelabel.Name = "Typelabel";
            this.Typelabel.Size = new System.Drawing.Size(31, 13);
            this.Typelabel.TabIndex = 25;
            this.Typelabel.Text = "Type";
            // 
            // Fulltankradiobutton
            // 
            this.Fulltankradiobutton.AutoSize = true;
            this.Fulltankradiobutton.Location = new System.Drawing.Point(401, 75);
            this.Fulltankradiobutton.Name = "Fulltankradiobutton";
            this.Fulltankradiobutton.Size = new System.Drawing.Size(69, 17);
            this.Fulltankradiobutton.TabIndex = 24;
            this.Fulltankradiobutton.TabStop = true;
            this.Fulltankradiobutton.Text = "Full Tan&k";
            this.Fulltankradiobutton.UseVisualStyleBackColor = true;
            // 
            // FixedamountradioButton
            // 
            this.FixedamountradioButton.AutoSize = true;
            this.FixedamountradioButton.Location = new System.Drawing.Point(401, 50);
            this.FixedamountradioButton.Name = "FixedamountradioButton";
            this.FixedamountradioButton.Size = new System.Drawing.Size(89, 17);
            this.FixedamountradioButton.TabIndex = 23;
            this.FixedamountradioButton.TabStop = true;
            this.FixedamountradioButton.Text = "Fixed A&mount";
            this.FixedamountradioButton.UseVisualStyleBackColor = true;
            // 
            // DieselradioButton
            // 
            this.DieselradioButton.AutoSize = true;
            this.DieselradioButton.Location = new System.Drawing.Point(34, 84);
            this.DieselradioButton.Name = "DieselradioButton";
            this.DieselradioButton.Size = new System.Drawing.Size(54, 17);
            this.DieselradioButton.TabIndex = 22;
            this.DieselradioButton.TabStop = true;
            this.DieselradioButton.Text = "&Diesel";
            this.DieselradioButton.UseVisualStyleBackColor = true;
            // 
            // PetrolradioButton
            // 
            this.PetrolradioButton.AutoSize = true;
            this.PetrolradioButton.Location = new System.Drawing.Point(34, 51);
            this.PetrolradioButton.Name = "PetrolradioButton";
            this.PetrolradioButton.Size = new System.Drawing.Size(52, 17);
            this.PetrolradioButton.TabIndex = 21;
            this.PetrolradioButton.TabStop = true;
            this.PetrolradioButton.Text = "&Petrol";
            this.PetrolradioButton.UseVisualStyleBackColor = true;
            // 
            // Sales
            // 
            this.Sales.FormattingEnabled = true;
            this.Sales.Location = new System.Drawing.Point(385, 19);
            this.Sales.Name = "Sales";
            this.Sales.Size = new System.Drawing.Size(145, 95);
            this.Sales.TabIndex = 20;
            // 
            // Fuel
            // 
            this.Fuel.FormattingEnabled = true;
            this.Fuel.Location = new System.Drawing.Point(17, 19);
            this.Fuel.Name = "Fuel";
            this.Fuel.Size = new System.Drawing.Size(120, 95);
            this.Fuel.TabIndex = 19;
            // 
            // Addtobillbutton
            // 
            this.Addtobillbutton.Location = new System.Drawing.Point(562, 184);
            this.Addtobillbutton.Name = "Addtobillbutton";
            this.Addtobillbutton.Size = new System.Drawing.Size(75, 23);
            this.Addtobillbutton.TabIndex = 35;
            this.Addtobillbutton.Text = "Add &To Bill";
            this.Addtobillbutton.UseVisualStyleBackColor = true;
            this.Addtobillbutton.Click += new System.EventHandler(this.Addtobillbutton_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(48, 274);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(384, 164);
            this.panel2.TabIndex = 6;
            // 
            // Carnolabel
            // 
            this.Carnolabel.AutoSize = true;
            this.Carnolabel.Location = new System.Drawing.Point(122, 19);
            this.Carnolabel.Name = "Carnolabel";
            this.Carnolabel.Size = new System.Drawing.Size(38, 13);
            this.Carnolabel.TabIndex = 36;
            this.Carnolabel.Text = "Car no";
            // 
            // CarnotextBox
            // 
            this.CarnotextBox.Location = new System.Drawing.Point(245, 12);
            this.CarnotextBox.Name = "CarnotextBox";
            this.CarnotextBox.Size = new System.Drawing.Size(100, 20);
            this.CarnotextBox.TabIndex = 37;
            // 
            // AcessButton
            // 
            this.AcessButton.Location = new System.Drawing.Point(406, 8);
            this.AcessButton.Name = "AcessButton";
            this.AcessButton.Size = new System.Drawing.Size(75, 23);
            this.AcessButton.TabIndex = 38;
            this.AcessButton.Text = "&Access";
            this.AcessButton.UseVisualStyleBackColor = true;
            this.AcessButton.Click += new System.EventHandler(this.AcessButton_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Exitbutton);
            this.panel3.Controls.Add(this.AboutButton);
            this.panel3.Controls.Add(this.NextcustomerButton);
            this.panel3.Controls.Add(this.BillButton);
            this.panel3.Location = new System.Drawing.Point(547, 307);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 131);
            this.panel3.TabIndex = 39;
            // 
            // BillButton
            // 
            this.BillButton.Location = new System.Drawing.Point(20, 27);
            this.BillButton.Name = "BillButton";
            this.BillButton.Size = new System.Drawing.Size(75, 23);
            this.BillButton.TabIndex = 0;
            this.BillButton.Text = "&Bill";
            this.BillButton.UseVisualStyleBackColor = true;
            // 
            // NextcustomerButton
            // 
            this.NextcustomerButton.Location = new System.Drawing.Point(101, 14);
            this.NextcustomerButton.Name = "NextcustomerButton";
            this.NextcustomerButton.Size = new System.Drawing.Size(75, 49);
            this.NextcustomerButton.TabIndex = 1;
            this.NextcustomerButton.Text = "&Next Customer";
            this.NextcustomerButton.UseVisualStyleBackColor = true;
            // 
            // AboutButton
            // 
            this.AboutButton.Location = new System.Drawing.Point(20, 74);
            this.AboutButton.Name = "AboutButton";
            this.AboutButton.Size = new System.Drawing.Size(75, 23);
            this.AboutButton.TabIndex = 2;
            this.AboutButton.Text = "Ab&out";
            this.AboutButton.UseVisualStyleBackColor = true;
            // 
            // Exitbutton
            // 
            this.Exitbutton.Location = new System.Drawing.Point(102, 74);
            this.Exitbutton.Name = "Exitbutton";
            this.Exitbutton.Size = new System.Drawing.Size(75, 23);
            this.Exitbutton.TabIndex = 3;
            this.Exitbutton.Text = "E&xit";
            this.Exitbutton.UseVisualStyleBackColor = true;
            this.Exitbutton.Click += new System.EventHandler(this.Exitbutton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Amountlist);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.BilllistBox);
            this.groupBox1.Location = new System.Drawing.Point(17, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(350, 158);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bill";
            // 
            // Amountlist
            // 
            this.Amountlist.FormattingEnabled = true;
            this.Amountlist.Location = new System.Drawing.Point(279, 36);
            this.Amountlist.Name = "Amountlist";
            this.Amountlist.Size = new System.Drawing.Size(62, 95);
            this.Amountlist.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(276, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Amount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(136, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Liters";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(75, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Fuel";
            // 
            // BilllistBox
            // 
            this.BilllistBox.FormattingEnabled = true;
            this.BilllistBox.Location = new System.Drawing.Point(17, 44);
            this.BilllistBox.Name = "BilllistBox";
            this.BilllistBox.Size = new System.Drawing.Size(162, 95);
            this.BilllistBox.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.AcessButton);
            this.Controls.Add(this.Carnolabel);
            this.Controls.Add(this.CarnotextBox);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "UOB Service station form";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Addtobillbutton;
        private System.Windows.Forms.CheckBox GearcheckBox;
        private System.Windows.Forms.CheckBox EnginecheckBox;
        private System.Windows.Forms.ListBox OilChange;
        private System.Windows.Forms.Label displayliters;
        private System.Windows.Forms.Label Literslabel;
        private System.Windows.Forms.TextBox AmounttextBox;
        private System.Windows.Forms.Label Amountlabel;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.ComboBox TypecomboBox;
        private System.Windows.Forms.Label Typelabel;
        private System.Windows.Forms.RadioButton Fulltankradiobutton;
        private System.Windows.Forms.RadioButton FixedamountradioButton;
        private System.Windows.Forms.RadioButton DieselradioButton;
        private System.Windows.Forms.RadioButton PetrolradioButton;
        private System.Windows.Forms.ListBox Sales;
        private System.Windows.Forms.ListBox Fuel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Carnolabel;
        private System.Windows.Forms.TextBox CarnotextBox;
        private System.Windows.Forms.Button AcessButton;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Exitbutton;
        private System.Windows.Forms.Button AboutButton;
        private System.Windows.Forms.Button NextcustomerButton;
        private System.Windows.Forms.Button BillButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox Amountlist;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox BilllistBox;
    }
}

